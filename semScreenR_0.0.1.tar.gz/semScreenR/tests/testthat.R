library(testthat)
library(semScreenR)
test_check("semScreenR")
